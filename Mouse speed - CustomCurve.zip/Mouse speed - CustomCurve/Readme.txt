Safety: 
1. Uploading this exe to VirusTotal and MetaDefender yields 0 anti-virus programs detecting suspicious activity. 
2. MetaDefender running it in a sandbox and analyzing its activity finds no suspicious activity. 
3. Virus Total shows the file was first analyzed in 2012.

Source:
1. This file was found via this discussion. 
https://superuser.com/a/1275828

2. That answer linked to this download page:
https://www.esreality.com/post/2363191/custom-mouse-accel-program-for-windows/

Using this program is straight-forward. Example: changing v4 from 450 to 1000 results in the fastest stage of mouse travel increasing speed, while all other mouse behavior remains the same.
---------------------------------------------
Custom Curve 1.1

This program allows a user to adjust the mouse acceleration curve in Windows.

.NET Framework 4.0 or newer is required.

*WARNING* Use at your own risk!  Careless entries may result in an unresponsive pointer!

Check the 'Guide' under the 'Help' menu.

For more info, check out hoppans tutorial at ESR: http://www.esreality.com/index.php?a=post&id=1945096

Other resources:
http://donewmouseaccel.blogspot.com/2009/06/out-of-sync-and-upside-down-windows.html
http://msdn.microsoft.com/en-us/windows/hardware/gg463319.aspx

---------------------------------------------

